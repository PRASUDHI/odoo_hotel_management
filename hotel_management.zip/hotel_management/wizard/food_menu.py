
from odoo import fields, models, api


class FoodMenuTransient(models.TransientModel):
    _name = 'food.menu'
    _description = 'Food order'
    name = fields.Char(readonly=True)
    quantity = fields.Integer()
    company_id = fields.Many2one('res.company', store=True, copy=False,
                                 string="Company",
                                 default=lambda self:
                                 self.env.user.company_id.id)
    currency_id = fields.Many2one('res.currency', string="Currency",
                                  related='company_id.currency_id',
                                  default=lambda self:
                                  self.env.user.company_id.currency_id.id)
    price = fields.Monetary(readonly=True)
    description=fields.Html()
    image = fields.Binary(readonly=True)
    order_list_id = fields.Many2one('order.food')
    total = fields.Float(compute="_compute_total")

    @api.depends('price', 'quantity')
    def _compute_total(self):
        for record in self:
            record.total = record.price * record.quantity



    # def action_create_list(self):
    #
    #     print(self.name)
    #     print(self.quantity)
    #     print(self.order_list_id)
    #     vals={
    #         'name': self.name,
    #         'quantity': self.quantity,
    #         'food_list_id':self.order_list_id.id,
    #     }
    #     print(vals)
    #     self.env['order.list'].create(vals)








