from odoo import models, fields, _, api, Command
from odoo.exceptions import ValidationError
from datetime import timedelta, date, datetime


class HotelAccommodation(models.Model):
    _name = "hotel.accommodation"
    _description = "Hotel Accommodation"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = "reference_number"
    _order = 'check_in desc'

    reference_number = fields.Char(default=lambda self: _('New'), readonly=True, copy=False,
                                   help="Reference Number of the book")
    name = fields.Many2one('hotel.guest', string="Name", )
    guest_id = fields.Many2one('res.partner', string="Guest Name", domain="[('is_hotel_guest', '=', True)]")
    address = fields.Text(string="Address", compute="_compute_address")
    street = fields.Char(related='guest_id.street', string="Address")
    street2 = fields.Char(related='guest_id.street2', string="Street 2")
    city = fields.Char(related='guest_id.city', string="City")
    zip = fields.Char(related='guest_id.zip', string="ZIP")
    guest_ids = fields.Many2many('res.partner', string='Guests')
    number_of_guests = fields.Integer(string="Number of Guests", default=1)
    check_in = fields.Datetime("Check In")
    check_out = fields.Datetime("Check Out")
    address_attach = fields.Binary(
        attachment=True,
        string="Address Proof",
        copy=False,

    )
    bed = fields.Selection(
        string='Bed',
        selection=[('single', 'Single'), ('double', 'Double'), ('dormitory', 'Dormitory')]
    )
    facility = fields.Many2many('hotel.facility', string="Facility")
    rooms_id = fields.Many2one('hotel.rooms', string="Room")
    filtered_room_ids = fields.Many2many('hotel.rooms', compute='_compute_filtered_rooms', string="Filtered Rooms")
    room_status = fields.Selection([
        ('draft', 'Draft'),
        ('check_in', 'Check In'),
        ('check_out', 'Check Out'),
        ('cancel', 'Cancel')
    ], string='Room Status', default='draft')

    expected_days = fields.Integer(string='Expected Days')
    expected_date = fields.Date(string='Expected CheckOut', compute='_compute_expected_date', store=True, readonly=True)
    age = fields.Integer('Age')
    gender = fields.Selection(
        string='Gender',
        selection=[('male', 'Male'), ('female', 'Female')]
    )
    invoice_id = fields.Many2one('account.move', string="Invoice")

    payment_state = fields.Selection(related="invoice_id.payment_state", store=True, string="Payment State")
    move_type = fields.Selection(related="invoice_id.move_type", store=True, string="Move Type")
    accommodation_ids = fields.One2many('hotel.guest', 'accommodation_line_id')
    total_rent = fields.Float(string="Total Rent", compute="_compute_total_rent", store=True)
    food_total = fields.Float(string="Food Total", compute="_compute_food_total", store=True)
    total_amount = fields.Float(string="Total Amount", compute="_compute_total_amount", store=True,
                                currency_field="currency_id")
    company_id = fields.Many2one('res.company', store=True, copy=False, string="Company",
                                 default=lambda self: self.env.user.company_id.id)
    currency_id = fields.Many2one('res.currency', string="Currency", related="company_id.currency_id",
                                  default=lambda self: self.env.user.company_id.currency_id.id)

    order_list_ids = fields.One2many('order.list', 'accommodation_id', string="Food Orders")

    payment_line_ids = fields.One2many('hotel.payment.line', 'accommodation_id', string='Payment Lines')

    expected_date_color = fields.Char(compute='_compute_expected_date_color', store=False)


    @api.depends('check_out', 'expected_date','room_status')
    def _compute_expected_date_color(self):
        """
            Yellow: Expected date = current day
            Red: Expected date = current day but not Check-out
        """

        today = date.today()
        for rec in self:
            if rec.room_status != 'check_in' or not rec.expected_date:
                rec.expected_date_color = ''
                continue
            if rec.expected_date == today:
                rec.expected_date_color = 'yellow'
            elif rec.expected_date < today:
                rec.expected_date_color = 'red'
            else:
                rec.expected_date_color = ''




    @api.depends('order_list_ids.total')
    def _compute_food_total(self):
        """
        Calculate total food by each order line
        """
        for rec in self:
            rec.food_total = sum(line.total for line in rec.order_list_ids)

    @api.depends('check_in', 'check_out', 'rooms_id.rent')
    def _compute_total_rent(self):
        """
                compute the total rent based on check_in ,check_out and rent of that particular room.
        """
        for rec in self:
            if rec.check_in and rec.check_out and rec.rooms_id:
                delta = rec.check_out.date() - rec.check_in.date()
                num_days = delta.days
                if num_days == 0:
                    num_days = 1
                rec.total_rent = num_days * rec.rooms_id.rent

            else:
                rec.total_rent = rec.rooms_id.rent

    @api.depends('food_total')
    def _compute_total_amount(self):
        """
                Compute the total amount of food and rent
        """
        for rec in self:
            rec.total_amount = rec.total_rent + rec.food_total

    @api.depends('facility', 'bed')
    def _compute_filtered_rooms(self):
        """
                Filter the rooms based on bed type,facility,state, otherwise show all rooms
        """
        for rec in self:
            domain = []
            if rec.facility:
                domain.append(('facility', 'in', rec.facility.ids))
            if rec.bed:
                domain.append(('bed', '=', rec.bed))
            domain.append(('state', '=', 'available'))

            rec.filtered_room_ids = self.env['hotel.rooms'].search(domain)

    @api.depends('expected_days', 'check_in','room_status')
    def _compute_expected_date(self):
        """
               Calculate the expected date based on check_in and expected date
        """
        for record in self:
            if record.room_status == 'check_in' and record.check_in:
                if record.expected_days == 0:
                    record.expected_date = record.check_in.date()
                else:
                    record.expected_date = (record.check_in + timedelta(days=record.expected_days)).date()
            else:
                record.expected_date = False



    @api.constrains('number_of_guests')
    def guest_numbers(self):
        """
                Check the number of guests equal to the enter guest
        """
        for record in self:
            if record.number_of_guests != len(record.guest_id) + len(record.accommodation_ids):
                raise ValidationError("Enter guest must be equal to number of Guest")

    def write(self, vals):
        """
            Update the record after the validation error in guest number
        """
        result = super(HotelAccommodation, self).write(vals)
        self.guest_numbers()
        return result

    @api.depends('guest_id')
    def _compute_address(self):
        """
            join the address of guest
        """
        for rec in self:
            res = [rec.guest_id.street, rec.guest_id.street2,
                   rec.guest_id.city,
                   rec.guest_id.zip]
            self.address = ', '.join(filter(bool, res))

    def create(self, vals):
        """
            For creating Reference number
        """
        if vals.get('reference_number', _('New')) == _('New'):
            vals['reference_number'] = self.env['ir.sequence'].next_by_code('hotel.accommodation')
        return super(HotelAccommodation, self).create(vals)

    def action_check_in(self):
        """
            Action for check_in, if the address proof attachment is not added in chatter raise a validation error,
            Change the room_status to Check in and room state to unavailable
            Record the Datetime in field CheckIn

            Update the room_rent automatically in payment tab
        """
        for record in self:
            if record.message_attachment_count == 0:
                raise ValidationError("Please add attachment")
            record.room_status = 'check_in'
            record.rooms_id.state = 'not_available'
            record.check_in = fields.Datetime.now()

            room_rent = {
                'name': 'Room Rent',
                'description': 'Room Rent',
                'quantity': 1,
                'price': self.rooms_id.rent,
                'total': self.total_rent,
                'accommodation_id': self.id,

            }
            value = self.env['hotel.payment.line'].create(room_rent)
            return value

    def action_check_out(self):
        """
            Action for check_out,Record the Datetime in field Checkout
            Calculate the rent based on checkout date,Room state change to available
            Opens the invoice with the room rent and food order list

        """
        for record in self:
            record.room_status = 'check_out'
            record.check_out = fields.Datetime.now()
            if record.check_in and record.check_out and record.rooms_id:
                # num_days = record.check_out.date() - record.check_in.date()
                delta = record.check_out.date() - record.check_in.date()
                num_days = delta.days
                if num_days == 0:
                    num_days = 1
                record.total_rent = num_days * record.rooms_id.rent
            if record.rooms_id:
                record.rooms_id.state = 'available'

        invoice = self.env['account.move'].create({
            'partner_id': self.guest_id.id,
            'move_type': 'out_invoice',
            'invoice_line_ids': [
                Command.create({
                    'name': line.name,
                    'quantity': line.quantity,
                    'price_unit': line.price,
                    'product_uom_id': line.uom_id.id,
                }) for line in self.payment_line_ids],

        })
        record.invoice_id = invoice.id
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'res_id': invoice.id,
            'view_mode': 'form',
        }

    def action_cancel(self):
        """
            Action to cancel the Accommodation
        """
        for record in self:
            record.room_status = 'cancel'
